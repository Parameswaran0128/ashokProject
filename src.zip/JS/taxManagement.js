//taxManagement

function addOrUpdateTax() {
    const goodstype=prompt('Enter the goods type: ');
    if(goodstype==="groceries"||goodstype==="household"||goodstype==="stationary"||goodstype==="fruits"){
        const cgst=prompt('Enter the cgst tax: ');
        const sgst=prompt('Enter the sgst tax: ');
        const igst=prompt('Enter the igst tax: ');
        document.getElementById('result').innerHTML = `New Taxes updated for the goodstype: " ${goodstype} "`;
    }
    else{
        alert('Goods Type Not Found!')
    }
}

function getTaxForMonth() {
    const month = prompt('Enter the month (1-12):');
    const year = prompt('Enter the year:');
    
    if (month && year) {
        // Generate random CGST, SGST, and IGST values
        const totalCGST = Math.random() * 500; // Random total CGST between 0 and 500
        const totalSGST = Math.random() * 500; // Random total SGST between 0 and 500
        const totalIGST = Math.random() * 100; // Random total IGST between 0 and 100

        // Display the randomly generated tax details for the month
        const result = `
            Total CGST for the month: $${totalCGST.toFixed(2)}
            <br>
            Total SGST for the month: $${totalSGST.toFixed(2)}
            <br>
            Total IGST for the month: $${totalIGST.toFixed(2)}
        `;
        document.getElementById('result').innerHTML = result;
    } else {
        alert('Please enter valid month and year.');
    }
}

