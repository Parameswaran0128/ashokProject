function removeProduct(){
    alert("Removed Successfully");
}