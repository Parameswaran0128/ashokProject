function loadIframe(url) {
    const iframeContainer = document.getElementById('iframeContainer');
    
    // Clear previous iframe if exists
    while (iframeContainer.firstChild) {
        iframeContainer.removeChild(iframeContainer.firstChild);
    }

    // Create iframe element
    const iframe = document.createElement('iframe');
    iframe.src = url;
    iframe.width = '100%';
    iframe.height = '500px'; // Adjust height as needed
    iframe.frameborder = '0';
    
    // Append iframe to container
    iframeContainer.appendChild(iframe);
}
function login(){
    window.location.href="index.html";s
}
