function addProduct() {
    // Get form data
    const productName = document.getElementById('productName').value;
    const quantity = document.getElementById('quantity').value;
    const costPrice = document.getElementById('costPrice').value;
    const sellingPrice = document.getElementById('sellingPrice').value;
    const discount = document.getElementById('discount').value;
    const cgst = document.getElementById('cgst').value;
    const sgst = document.getElementById('sgst').value;
    const igst = document.getElementById('igst').value;

    // Create object for product
    const product = {
        productName: productName,
        quantity: quantity,
        costPrice: costPrice,
        sellingPrice: sellingPrice,
        discount: discount,
        cgst: cgst,
        sgst: sgst,
        igst: igst
    };

    // Store product details in local storage
    const products = JSON.parse(localStorage.getItem('products')) || [];
    products.push(product);
    localStorage.setItem('products', JSON.stringify(products));

    // Alert success message
    alert('Product added successfully');
}
