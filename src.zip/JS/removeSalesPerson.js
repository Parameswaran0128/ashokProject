//removeSalesPerson

function removeSalesPerson(){
    const username = document.getElementById('username').value
    if(username==="sales"){
        alert(`Credentials removed for the : ${username}`);
    }
    else if(username==="manager"){
        alert(`Credentials removed for the : ${username}`);
    }
    else{
        alert("Invalid Username");
    }

}