function myFunction() {
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    //xurl="saledashboard.html"
    if (username === "sales" && password === "123") {
        window.open("saledashboard.html");
    } else if (username === "manager" && password === "123") {
        window.open("managerdashboard.html");
    } else {
        alert("Please enter correct credentials.");
    }
}