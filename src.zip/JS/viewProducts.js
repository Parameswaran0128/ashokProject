document.getElementById('viewAllProductsBtn').addEventListener('click', function() {
    // Sample product data
    const products = [
        { id: '001', name: 'pencil', type: 'stationary', quantity: 3, price: 12.98 },
        { id: '002', name: 'pen', type: 'stationary', quantity: Math.floor(Math.random() * 20) + 1, price: Math.random() * (50 - 10) + 10 },
        { id: '003', name: 'notebook', type: 'stationary', quantity: Math.floor(Math.random() * 30) + 1, price: Math.random() * (100 - 20) + 20 },
        { id: '004', name: 'marker', type: 'stationary', quantity: Math.floor(Math.random() * 15) + 1, price: Math.random() * (30 - 5) + 5 },
        { id: '005', name: 'calculator', type: 'electronics', quantity: Math.floor(Math.random() * 10) + 1, price: Math.random() * (200 - 50) + 50 },
        { id: '006', name: 'headphones', type: 'electronics', quantity: Math.floor(Math.random() * 15) + 1, price: Math.random() * (1000 - 200) + 200 },
        { id: '007', name: 'backpack', type: 'accessories', quantity: Math.floor(Math.random() * 10) + 1, price: Math.random() * (150 - 30) + 30 },
        { id: '008', name: 'water bottle', type: 'household', quantity: Math.floor(Math.random() * 25) + 1, price: Math.random() * (50 - 10) + 10 },
        { id: '009', name: 'sunglasses', type: 'fashion', quantity: Math.floor(Math.random() * 20) + 1, price: Math.random() * (200 - 50) + 50 },
        { id: '010', name: 'flashlight', type: 'tools', quantity: Math.floor(Math.random() * 10) + 1, price: Math.random() * (50 - 10) + 10 }
    ];

    // Get the table body element
    const tableBody = document.getElementById('productsTableBody');

    // Clear existing table rows
    tableBody.innerHTML = '';

    // Populate the table with product data
    products.forEach(product => {
        const row = tableBody.insertRow();
        row.innerHTML = `
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${product.type}</td>
            <td>${product.quantity}</td>
            <td>${product.price.toFixed(2)}</td>
        `;
    });
});
