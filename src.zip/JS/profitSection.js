//profitSection

function viewProfit() {
    const fromDate = document.getElementById('fromDate').value;
    if (fromDate) {
        // Assuming you have the total profit and profit percentage values available
        const totalProfit = 3819.0;
        const profitPercentage = 34.22;

        // Display the total profit and profit percentage
        const result = `
            Total profit from ${fromDate} onwards: ₹${totalProfit.toFixed(2)}
            <br>
            Profit Percentage: ${profitPercentage.toFixed(2)}%
        `;
        document.getElementById('result').innerHTML = result;
    } else {
        alert('Please enter a valid date.');
    }
}
