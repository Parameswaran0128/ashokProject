package project;
import java.util.*;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class Sales {
	Sales(){
		loadPage();
	}
//	static String pid=new String();
//	static int quan;
	Scanner sc=new Scanner(System.in);
	
	public static final Map<String, Integer> cart = new HashMap<>();
	private void loadPage() {
        while (true) {
            System.out.println();
            System.out.println("SsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSs");
            System.out.println();
            System.out.println("              Press '1' for Create Bill");
            System.out.println();
            System.out.println("              Press '2' for Add Products");
            System.out.println();
            System.out.println("              Press '3' for Edit Products");
            System.out.println();
            System.out.println("             Press '4' for Delete Products");
            System.out.println();
            System.out.println("           Press '5' for To view bill history ");
            System.out.println();
            System.out.println("                 Press '6' for Logout ");
            System.out.println();
            System.out.print("                  Enter your number:");
            int number = sc.nextInt();
            System.out.println();
            switch (number) {
                case 1:
                	Createbill cb=new Createbill();
                	cb.enterProducts();
                    break;
                case 2:
                	Addproducts ap=new Addproducts();
                    ap.addProducts();
                    break;
                case 3:
                    Updateproduct up=new Updateproduct();
                    up.updateProduct();
                    break;
                case 4:
                	Removeproduct rp=new Removeproduct();
                    rp.removeProduct();
                    break;
                case 5:
                	Saleshistory sh=new Saleshistory();
                	sh.viewHistory();
                	break;
                case 6:
                	return;

            }
        }
    }
	
	
	
}
