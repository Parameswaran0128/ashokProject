//package project;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class Viewproducts {
//	public void viewProducts() {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
//            String sql = "SELECT * FROM productdetails";
//            try (PreparedStatement statement = conn.prepareStatement(sql)) {
//                try (ResultSet resultSet = statement.executeQuery()) {
//                    // Display column headers
//                	if (!resultSet.isBeforeFirst()) {
//                        System.out.println("		No products available");
//                        return; // Return if there are no products
//                    }
//                    System.out.printf("%-5s %-10s %-20s %-8s %-12s %-12s %-8s %-6s %-6s %-6s%n",
//                            "ID", "Product ID", "Product Name", "Quantity", "Cost Price", "Selling Price", "Discount", "CGST", "SGST", "IGST");
//                    // Display each row of the result set
//                    while (resultSet.next()) {
//                        int id = resultSet.getInt("id");
//                        String productId = resultSet.getString("productid");
//                        String productName = resultSet.getString("productname");
//                        int quantity = resultSet.getInt("quantity");
//                        double costPrice = resultSet.getDouble("costprice");
//                        double sellingPrice = resultSet.getDouble("sellingprice");
//                        int discount = resultSet.getInt("discount");
//                        double cgst = resultSet.getDouble("cgst");
//                        double sgst = resultSet.getDouble("sgst");
//                        double igst = resultSet.getDouble("igst");
//                        System.out.printf("%-5d %-10s %-20s %-8d %-12.2f %-12.2f %-8d %-6.1f %-6.1f %-6.1f%n",
//                                id, productId, productName, quantity, costPrice, sellingPrice, discount, cgst, sgst, igst);
//                    }
//                }
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//    }
//}

package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Viewproducts {
    public void viewProducts() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            String sql = "SELECT * FROM productdetails";
            try (PreparedStatement statement = conn.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    // Display column headers
                    if (!resultSet.isBeforeFirst()) {
                        System.out.println("No products available");
                        return; // Return if there are no products
                    }
                    System.out.printf("%-5s %-10s %-20s %-20s %-8s %-12s %-12s %-8s %-6s %-6s %-6s%n",
                            "ID", "Product ID", "Product Name", "Goods Type", "Quantity", "Cost Price", "Selling Price", "Discount", "CGST", "SGST", "IGST");
                    // Display each row of the result set
                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String productId = resultSet.getString("productid");
                        String productName = resultSet.getString("productname");
                        String goodsType = resultSet.getString("goodstype");
                        int quantity = resultSet.getInt("quantity");
                        double costPrice = resultSet.getDouble("costprice");
                        double sellingPrice = resultSet.getDouble("sellingprice");
                        int discount = resultSet.getInt("discount");
                        double cgst = resultSet.getDouble("cgst");
                        double sgst = resultSet.getDouble("sgst");
                        double igst = resultSet.getDouble("igst");
                        System.out.printf("%-5d %-10s %-20s %-20s %-8d %-12.2f %-12.2f %-8d %-6.1f %-6.1f %-6.1f%n",
                                id, productId, productName, goodsType, quantity, costPrice, sellingPrice, discount, cgst, sgst, igst);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
