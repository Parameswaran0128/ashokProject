package project;
import java.io.FileReader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.*
;public class Printbill {
	public static Map<String,Integer> purchase=new HashMap();
	public static int billnumberinteger;
	public static String billnumberstring="";
    public static void generatePDFBill(Map<String, Integer> purchaseList) {
    	String payment=choiceofPay(); 	
    	billnumberinteger=0;
    	billnumberstring="";
    	generateRandomBillNumber();
    	String fname="bill";
    	String lname=fname+billnumberstring;
        String fileName = lname+".pdf"; // Name of the PDF file
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();
            
            // Add Heading with color
            Font headingFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
            headingFont.setColor(new BaseColor(22, 160, 133)); // Setting color to #16a085
            Paragraph heading = new Paragraph("Shop Billing Management", headingFont);
            heading.setAlignment(Element.ALIGN_CENTER);
            document.add(heading);

            Paragraph spac = new Paragraph("\n"); // Add multiple '\n' for more space
            document.add(spac);
            
            // Add Sub-heading
            Font subHeadingFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLDITALIC);
            Paragraph subHeading = new Paragraph("Tax Invoice", subHeadingFont);
            subHeading.setAlignment(Element.ALIGN_CENTER);
            document.add(subHeading);
            
            Paragraph space = new Paragraph("\n"); // Add multiple '\n' for more space
            document.add(space);
            
            LocalDateTime generationDatetime = LocalDateTime.now();

            // Format date and time
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedDateTime = generationDatetime.format(formatter);

            // Create Bill Details Table
            PdfPTable billDetailsTable = new PdfPTable(2);
            billDetailsTable.setWidthPercentage(100);
            String billingPerson = getBillingPerson();
            PdfPCell billCell = new PdfPCell(new Paragraph("Billing Person: " + billingPerson));
            billCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            billCell.setBorder(PdfPCell.NO_BORDER);
            billDetailsTable.addCell(billCell);

            

            Paragraph generationDateTimeParagraph = new Paragraph("Bill No: " + billnumberstring);
            generationDateTimeParagraph.setAlignment(Element.ALIGN_LEFT);
            document.add(generationDateTimeParagraph);
         
            
            
            Paragraph billingPersonParagraph = new Paragraph("Bill Generated Date and Time: " + formattedDateTime);
            billingPersonParagraph.setAlignment(Element.ALIGN_LEFT);
            document.add(billingPersonParagraph);
//            document.add(space);

            
            
            
            PdfPCell modeOfPayCell = new PdfPCell(new Paragraph(("Mode of Pay: ")+payment));
            modeOfPayCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            modeOfPayCell.setBorder(PdfPCell.NO_BORDER);
            billDetailsTable.addCell(modeOfPayCell);
            document.add(billDetailsTable);
            document.add(space);

            // Create and add the table
            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            addTableHeader(table);
            addRows(table, purchaseList, conn);
            document.add(table);

            // Remaining Details
            Font boldFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            Paragraph remainingDetails = new Paragraph("\nAmount Details:\n", boldFont);

            // Add remaining details from the map
            double totalPrice=0.0;
            double totalCGST = 0;
            double totalSGST = 0;
            double totalIGST = 0;
            double totalGSTAmount = 0;
            double totalAfterGST = 0 ;
            double totalAfterDiscount = 0;
            int dis=0;

            for (Map.Entry<String, Integer> entry : purchaseList.entrySet()) {
                String productId = entry.getKey();
                int quantity = entry.getValue();
                

                String sqlSelect = "SELECT * FROM productdetails WHERE productid = ?";
                try (PreparedStatement selectStatement = conn.prepareStatement(sqlSelect)) {
                    selectStatement.setString(1, productId);
                    try (ResultSet resultSet = selectStatement.executeQuery()) {
                        if (resultSet.next()) {
                            double sellingPrice = resultSet.getDouble("sellingprice");
                            int discount = resultSet.getInt("discount");
                            double cgst = resultSet.getDouble("cgst");
                            double sgst = resultSet.getDouble("sgst");
                            double igst = resultSet.getDouble("igst");

                            totalPrice+=sellingPrice*quantity;
                            totalCGST += cgst;
                            totalSGST += sgst;
                            totalIGST += igst;
                            dis+=discount;
                        }
                    }
                }
            }
            totalGSTAmount=(((totalCGST+totalSGST+totalIGST)/100.0)*totalPrice);
            totalAfterGST=totalPrice+totalGSTAmount;
            totalAfterDiscount=totalAfterGST-((dis/100.0)*totalAfterGST);
            // Add the calculated totals to the remaining details
            remainingDetails.add("Total Price For All Products: Rs." +totalPrice+"\n");
            remainingDetails.add("Total CGST For All Products: " + totalCGST +"%"+ "\n");
            remainingDetails.add("Total SGST For All Products: " + totalSGST +"%"+"\n");
            remainingDetails.add("Total IGST For All Products: " + totalIGST +"%"+"\n");
            remainingDetails.add("Total GST Amount: Rs."+ totalGSTAmount+"\n");
            remainingDetails.add("Total Price After GST: Rs." + totalAfterGST + "\n");
            remainingDetails.add("Total Discount: " + dis+"%" + "\n");
            remainingDetails.add("Total Price After Discount: Rs." + totalAfterDiscount + "\n");

            document.add(remainingDetails);
            document.add(space);

            // Footer
            Font footerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC);
            Paragraph footer = new Paragraph("Thank you for visiting. Please come again soon.", footerFont);
            footer.setAlignment(Element.ALIGN_CENTER);
            document.add(footer);

            document.close();

            System.out.println("	Bill generated successfully and saved as " + fileName);
            purchase=purchaseList;
            Saleshistory sh=new Saleshistory();
            sh.addHistory(purchase,billnumberstring,payment);
//            ,totalAfterDiscount,totalAfterGST
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password");
                    PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO billno (bill_no) VALUES (?)")) {

                   // Set the value of new bill number in the prepared statement
                   preparedStatement.setInt(1, billnumberinteger);

                   // Execute the SQL query to insert new bill number
                   int rowsAffected = preparedStatement.executeUpdate();

                   // Check if the insertion was successful
                   if (rowsAffected > 0) {
                	   System.out.println();
                       System.out.println("	New bill number inserted successfully: " +billnumberinteger );
                   } else {
                       System.out.println("Failed to insert new bill number.");
                   }
               } catch (SQLException e) {
                   e.printStackTrace();
               }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String choiceofPay() {
    	Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println();
			System.out.println("	Mode of Pay");
			System.out.println();
			System.out.println("	Enter 1 for cash");
			System.out.println();
			System.out.println("	Enter 2 for online");
			System.out.println();
			System.out.print("	Enter your choice: ");
			int pay=sc.nextInt();
			switch(pay) {
			case 1:
				return "Cash";
			case 2:
				return "Online";
			}
			
		}
		
	}

	private static String generateRandomBillNumber() {
    	String sqlQuery = "SELECT bill_no FROM billno ORDER BY id DESC LIMIT 1";
    	
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password");
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sqlQuery)) {

            // Check if resultSet has any rows
            if (resultSet.next()) {
                int topBillNo = resultSet.getInt("bill_no");
//                System.out.println("Top Bill Number: " + topBillNo);
                billnumberinteger=topBillNo;
                billnumberinteger++;
                billnumberstring+=billnumberinteger;
            } else {
                System.out.println("No records found in the billno table.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return billnumberstring;
    }

    private static void addTableHeader(PdfPTable table) {
        String[] headers = {"Product ID", "Product Name", "Quantity", "Selling Price", "Discount","Total Price"};
        Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Paragraph(header, headerFont));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }
    }

    private static void addRows(PdfPTable table, Map<String, Integer> purchaseList, Connection conn) throws SQLException {
        for (Map.Entry<String, Integer> entry : purchaseList.entrySet()) {
            String productId = entry.getKey();
            int quantity = entry.getValue();

            String sqlSelect = "SELECT * FROM productdetails WHERE productid = ?";
            try (PreparedStatement selectStatement = conn.prepareStatement(sqlSelect)) {
                selectStatement.setString(1, productId);
                try (ResultSet resultSet = selectStatement.executeQuery()) {
                    if (resultSet.next()) {
                        String productName = resultSet.getString("productname");
                        double sellingPrice = resultSet.getDouble("sellingprice");
                        int discount = resultSet.getInt("discount");

                        table.addCell(productId);
                        table.addCell(productName);
                        table.addCell(String.valueOf(quantity));
                        table.addCell(String.valueOf(sellingPrice));
                        table.addCell(String.valueOf(discount));
                        table.addCell(String.valueOf(quantity*sellingPrice));
                    }
                }
            }
        }
    }

    private static double calculateTotalPriceAfterDiscount(double sellingPrice,int quantity, int discount) {
        return ((discount/100.0)*(sellingPrice*quantity));
    }
    private static String getBillingPerson() {
        String billingPerson = null;
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/login.json")) {
            // Parse the JSON file
            Object obj = parser.parse(reader);
            JSONObject jsonObject = (JSONObject) obj;

            // Retrieve the billing person
            billingPerson = (String) jsonObject.get("username");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return billingPerson;
    }
}





