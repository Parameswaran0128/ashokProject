//package project;
//import java.util.*;
//import java.io.FileReader;
//import java.io.IOException;
//import java.math.BigDecimal;
//import java.sql.*;
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import java.util.HashMap;
//
//public class Manager {
//    Scanner sc = new Scanner(System.in);
//
//    Manager() {
//        loadPage();
//    }
//
//    private void loadPage() {
//        while (true) {
//            System.out.println();
//            System.out.println("mMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmM");
//            System.out.println();
//            System.out.println("             Press '1' for View Products");
//            System.out.println();
//            System.out.println("              Press '2' for Add Products");
//            System.out.println();
//            System.out.println("              Press '3' for Edit Products");
//            System.out.println();
//            System.out.println("             Press '4' for Delete Products");
//            System.out.println();
//            System.out.println("              Press '5' for Manage Sales ");
//            System.out.println();
//            System.out.println("                 Press '6' for Logout ");
//            System.out.println();
//            System.out.print("                  Enter your number:");
//            int number = sc.nextInt();
//            System.out.println();
//            switch (number) {
//                case 1:
//                	Viewproducts vp=new Viewproducts();
//                    vp.viewProducts();
//                    break;
//                case 2:
//                	Addproducts ap=new Addproducts();
//                    ap.addProducts();
//                    break;
//                case 3:
//                    Updateproduct up=new Updateproduct();
//                    up.updateProduct();
//                case 4:
//                	Removeproduct rp=new Removeproduct();
//                    rp.removeProduct();
//                    break;
//                case 5:
//                   Managesales ms=new Managesales();
//                   ms.askChoice();
//                case 6:
//                	return;
//
//            }
//        }
//    }
//
//    private void viewProducts() {
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
//            String sql = "SELECT * FROM productdetails";
//            try (PreparedStatement statement = conn.prepareStatement(sql)) {
//                try (ResultSet resultSet = statement.executeQuery()) {
//                    // Display column headers
//                    System.out.printf("%-5s %-10s %-20s %-8s %-12s %-12s %-8s %-6s %-6s %-6s%n",
//                            "ID", "Product ID", "Product Name", "Quantity", "Cost Price", "Selling Price", "Discount", "CGST", "SGST", "IGST");
//                    // Display each row of the result set
//                    while (resultSet.next()) {
//                        int id = resultSet.getInt("id");
//                        String productId = resultSet.getString("productid");
//                        String productName = resultSet.getString("productname");
//                        int quantity = resultSet.getInt("quantity");
//                        double costPrice = resultSet.getDouble("costprice");
//                        double sellingPrice = resultSet.getDouble("sellingprice");
//                        int discount = resultSet.getInt("discount");
//                        double cgst = resultSet.getDouble("cgst");
//                        double sgst = resultSet.getDouble("sgst");
//                        double igst = resultSet.getDouble("igst");
//                        System.out.printf("%-5d %-10s %-20s %-8d %-12.2f %-12.2f %-8d %-6.1f %-6.1f %-6.1f%n",
//                                id, productId, productName, quantity, costPrice, sellingPrice, discount, cgst, sgst, igst);
//                    }
//                }
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//    }
//
//    private void addProducts() {
//        JSONArray productsArray = readJsonFile("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/products.json");
//
//        // Connect to MySQL database
//        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
//            // Iterate over each product
//            for (Object productObj : productsArray) {
//                JSONObject productJson = (JSONObject) productObj;
//
//                // Parse JSON object into a HashMap
//                HashMap<String, Object> productDetails = parseJsonToMap(productJson);
//
//                if (!productExists(conn, (String) productDetails.get("productid"))) {
//                    // Prepare SQL statement
//                    String sql = "INSERT INTO productdetails (productid, productname, quantity, costprice, sellingprice, discount, cgst, sgst, igst) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
//                    PreparedStatement statement = conn.prepareStatement(sql);
//
//                    // Set values from HashMap
//                    statement.setString(1, (String) productDetails.get("productid"));
//                    statement.setString(2, (String) productDetails.get("productname"));
//                    statement.setInt(3, (int) productDetails.get("quantity"));
//                    statement.setDouble(4, (Double) productDetails.get("costprice"));
//                    statement.setDouble(5, (Double) productDetails.get("sellingprice"));
//                    statement.setInt(6, (int) productDetails.get("discount"));
//                    statement.setDouble(7, (Double) productDetails.get("cgst"));
//                    statement.setDouble(8, (Double) productDetails.get("sgst"));
//                    statement.setDouble(9, (Double) productDetails.get("igst"));
//
//                    // Execute SQL statement
//                    int rowsInserted = statement.executeUpdate();
//                    if (rowsInserted > 0) {
//                        System.out.println("      A new product was inserted successfully!");
//                    }
//                } else {
//                    System.out.println("              Product already exists: " + productDetails.get("productname"));
//                }
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//    }
//
//    private static JSONArray readJsonFile(String filename) {
//        try {
//            JSONParser parser = new JSONParser();
//            FileReader reader = new FileReader(filename);
//            return (JSONArray) parser.parse(reader);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//
//    private static HashMap<String, Object> parseJsonToMap(JSONObject jsonObject) {
//        HashMap<String, Object> map = new HashMap<>();
//        for (Object key : jsonObject.keySet()) {
//            String keyStr = (String) key;
//            Object value = jsonObject.get(keyStr);
//            // Check the data type and handle accordingly
//            if (value instanceof Long) {
//                // Handle Long type appropriately, e.g., convert to Integer
//                map.put(keyStr, ((Long) value).intValue()); // Convert Long to Integer
//            } else {
//                map.put(keyStr, value);
//            }
//        }
//        return map;
//    }
//
//    private static boolean productExists(Connection conn, String productId) throws SQLException {
//        String sql = "SELECT COUNT(*) FROM productdetails WHERE productid = ?";
//        try (PreparedStatement statement = conn.prepareStatement(sql)) {
//            statement.setString(1, productId);
//            try (ResultSet resultSet = statement.executeQuery()) {
//                if (resultSet.next()) {
//                    int count = resultSet.getInt(1);
//                    return count > 0;
//                }
//            }
//        }
//        return false;
//    }
//}

package project;

import java.io.FileReader;
import java.sql.*;
import java.util.HashMap;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Manager {
    Scanner sc = new Scanner(System.in);

    Manager() {
        loadPage();
    }

    private void loadPage() {
        while (true) {
            System.out.println();
            System.out.println("mMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmMmM");
            System.out.println();
            System.out.println("             Press '1' for View Products");
            System.out.println();
            System.out.println("              Press '2' for Add Products");
            System.out.println();
            System.out.println("             Press '3' for Edit Products");
            System.out.println();
            System.out.println("            Press '4' for Delete Products");
            System.out.println();
            System.out.println("             Press '5' for Manage Sales ");
            System.out.println();
            System.out.println("           Press '6' for View bill history ");
            System.out.println();
            System.out.println("             Press '7' for create bill ");
            System.out.println();
            System.out.println("            Press '8' for Tax Management ");
            System.out.println();
            System.out.println("            Press '9' for Profit Section ");
            System.out.println();
            System.out.println("              Press '10' for Logout ");
            System.out.println();
            System.out.print("                Enter your number:");
            int number=sc.nextInt();
            
            switch (number) {
            case 1:
            	Viewproducts vp=new Viewproducts();
                vp.viewProducts();
                break;
            case 2:
            	Addproducts ap=new Addproducts();
                ap.addProducts();
                break;
            case 3:
                Updateproduct up=new Updateproduct();
                up.updateProduct();
                break;
            case 4:
            	Removeproduct rp=new Removeproduct();
                rp.removeProduct();
                break;
            case 5:
               Managesales ms=new Managesales();
               ms.askChoice();
               break;
            case 6:
            	Saleshistory sh=new Saleshistory();
            	sh.viewHistory();
            	break;
            case 7:
            	Createbill cb=new Createbill();
            	cb.enterProducts();
            	break;
            case 8:
            	Taxmanagement tm=new Taxmanagement();
            	tm.choice();
            	break;
            case 9:
            	Profit pt=new Profit();
            	pt.viewProfit();
            	break;
            case 10:
            	return;
            default:
                System.out.println("Invalid choice. Please enter a number between 1 and 10.");
                break;
        }
            
        }
    }

    private void viewProducts() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            String sql = "SELECT * FROM productdetails";
            try (PreparedStatement statement = conn.prepareStatement(sql)) {
                try (ResultSet resultSet = statement.executeQuery()) {
                    // Display column headers
                    System.out.printf("%-5s %-10s %-20s %-20s %-8s %-12s %-12s %-8s %-6s %-6s %-6s%n",
                            "ID", "Product ID", "Product Name", "Goods Type", "Quantity", "Cost Price", "Selling Price", "Discount", "CGST", "SGST", "IGST");
                    // Display each row of the result set
                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String productId = resultSet.getString("productid");
                        String productName = resultSet.getString("productname");
                        String goodsType = resultSet.getString("goodstype");
                        int quantity = resultSet.getInt("quantity");
                        double costPrice = resultSet.getDouble("costprice");
                        double sellingPrice = resultSet.getDouble("sellingprice");
                        int discount = resultSet.getInt("discount");
                        double cgst = resultSet.getDouble("cgst");
                        double sgst = resultSet.getDouble("sgst");
                        double igst = resultSet.getDouble("igst");
                        System.out.printf("%-5d %-10s %-20s %-20s %-8d %-12.2f %-12.2f %-8d %-6.1f %-6.1f %-6.1f%n",
                                id, productId, productName, goodsType, quantity, costPrice, sellingPrice, discount, cgst, sgst, igst);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addProducts() {
        JSONArray productsArray = readJsonFile("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/products.json");

        // Connect to MySQL database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            // Iterate over each product
            for (Object productObj : productsArray) {
                JSONObject productJson = (JSONObject) productObj;

                // Parse JSON object into a HashMap
                HashMap<String, Object> productDetails = parseJsonToMap(productJson);

                if (!productExists(conn, (String) productDetails.get("productid"))) {
                    // Prepare SQL statement
                    String sql = "INSERT INTO productdetails (productid, productname, goodstype, quantity, costprice, sellingprice, discount, cgst, sgst, igst) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement statement = conn.prepareStatement(sql);

                    // Set values from HashMap
                    statement.setString(1, (String) productDetails.get("productid"));
                    statement.setString(2, (String) productDetails.get("productname"));
                    statement.setString(3, (String) productDetails.get("goodstype"));
                    statement.setInt(4, (int) productDetails.get("quantity"));
                    statement.setDouble(5, (Double) productDetails.get("costprice"));
                    statement.setDouble(6, (Double) productDetails.get("sellingprice"));
                    statement.setInt(7, (int) productDetails.get("discount"));
                    statement.setDouble(8, (Double) productDetails.get("cgst"));
                    statement.setDouble(9, (Double) productDetails.get("sgst"));
                    statement.setDouble(10, (Double) productDetails.get("igst"));

                    // Execute SQL statement
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("      A new product was inserted successfully!");
                    }
                } else {
                    System.out.println("              Product already exists: " + productDetails.get("productname"));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static JSONArray readJsonFile(String filename) {
        try {
            JSONParser parser = new JSONParser();
            FileReader reader = new FileReader(filename);
            return (JSONArray) parser.parse(reader);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static HashMap<String, Object> parseJsonToMap(JSONObject jsonObject) {
        HashMap<String, Object> map = new HashMap<>();
        for (Object key : jsonObject.keySet()) {
            String keyStr = (String) key;
            Object value = jsonObject.get(keyStr);
            // Check the data type and handle accordingly
            if (value instanceof Long) {
                // Handle Long type appropriately, e.g., convert to Integer
                map.put(keyStr, ((Long) value).intValue()); // Convert Long to Integer
            } else {
                map.put(keyStr, value);
            }
        }
        return map;
    }

    private static boolean productExists(Connection conn, String productId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM productdetails WHERE productid = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, productId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }
        return false;
    }

}
