package project;

import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Profit {
    Scanner scanner = new Scanner(System.in);

    public void viewProfit() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password");) {
            // Prompt the user to enter the date
        	System.out.println();
        	System.out.println("To view Profit based on date");
        	System.out.println();
            System.out.print("Enter the date (YYYY-MM-DD): ");
            String fromDate = scanner.nextLine();

            // SQL query to calculate profit
//            String query = "SELECT SUM((bh.selling_price * bh.quantity) - (pd.costprice * bh.quantity)) AS total_profit " +
//                    "FROM bill_history bh " +
//                    "INNER JOIN productdetails pd ON bh.product_id = pd.productid " +
//                    "WHERE DATE(bh.generation_datetime) >= ?";
         // SQL query to calculate profit for a specific date
            String query = "SELECT SUM((bh.selling_price * bh.quantity) - (pd.costprice * bh.quantity)) AS total_profit " +
                    "FROM bill_history bh " +
                    "INNER JOIN productdetails pd ON bh.product_id = pd.productid " +
                    "WHERE DATE(bh.generation_datetime) = ?";


            // Prepare and execute the query
            try (PreparedStatement statement = conn.prepareStatement(query)) {
                statement.setString(1, fromDate);
                ResultSet resultSet = statement.executeQuery();

                // Retrieve and print the total profit
//                if (resultSet.next()) {
//                    double totalProfit = resultSet.getDouble("total_profit");
//                    System.out.println("Total profit from " + fromDate + " onwards: ₹" + totalProfit);
//
//                    // Additional feature: Calculate and display profit percentage
//                    double totalCost = getTotalCost(fromDate);
//                    if (totalCost != 0) {
//                        double profitPercentage = (totalProfit / totalCost) * 100;
//                        System.out.println("Profit Percentage: " + Math.round(profitPercentage * 100.0) / 100.0 + "%");
//                    } else {
//                        System.out.println("No cost data found for the specified date.");
//                    }
//                } else {
//                    System.out.println("No profit data found for the specified date.");
//                }
                if (resultSet.next()) {
                    double totalProfit = resultSet.getDouble("total_profit");
                    System.out.println("Total profit from " + fromDate + " onwards: ₹" + totalProfit);

                    // Additional feature: Calculate and display profit percentage
                    double totalCost = getTotalCost(fromDate);
                    if (totalCost != 0) {
                        double profitPercentage = (totalProfit / totalCost) * 100;
                        System.out.println("Profit Percentage: " + Math.round(profitPercentage * 100.0) / 100.0 + "%");
                    } else {
                        System.out.println("No cost data found for the specified date.");
                    }
                } else {
                    System.out.println("No profit data found for the specified date.");
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to calculate total cost
    private double getTotalCost(String fromDate) throws SQLException {
        double totalCost = 0;
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            String costQuery = "SELECT SUM(pd.costprice * bh.quantity) AS total_cost " +
                    "FROM bill_history bh " +
                    "INNER JOIN productdetails pd ON bh.product_id = pd.productid " +
                    "WHERE DATE(bh.generation_datetime) >= ?";
            try (PreparedStatement statement = conn.prepareStatement(costQuery)) {
                statement.setString(1, fromDate);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    totalCost = resultSet.getDouble("total_cost");
                }
            }
        }
        return totalCost;
    }
}
