package project;
import java.util.*;
public class Main {
	
	public static void runMain() {
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("--------------Shop Billing Management--------------");
			System.out.println();
			System.out.println("               Press '1' for Login ");
			System.out.println();
			System.out.println("            Press '2' for Exit System");
			System.out.println();
			System.out.print("                Enter the number: ");
			int user=sc.nextInt();
			System.out.println();
			System.out.println("-------------xxxxxxxxxxxxxxxxxxxxxxxxx---------------");
			System.out.println();
			
			switch(user) {
			case 1:
				Login ln=new Login();
				ln.validateLogin();
				break;
			case 2:
				return;
			default:
				System.out.println("            Please enter the correct number");
				System.out.println();
			}	
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		runMain();
	}

}