package project;

import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class Signup {
	public HashMap<String, String> credentials;

    Signup() {
        credentials = readCredentialsFromJson();
    }

    private HashMap<String, String> readCredentialsFromJson() {
        HashMap<String, String> credentialsMap = new HashMap<>();
        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/Signup.json"));
            JSONObject jsonObject = (JSONObject) obj;
            String username = (String) jsonObject.get("username");
            String password = (String) jsonObject.get("password");
            String confirmPassword = (String) jsonObject.get("confirmpassword");

            // Check if password and confirm password are the same
            if (!password.equals(confirmPassword)) {
                System.out.println("JSON is invalid. Password and confirm password do not match.");
                return null;
            }
            if (usernameExists(username)) {
                System.out.println("             Username already exists.");
                System.out.println();
                return null;
            }
            credentialsMap.put(username, password);
            addCredentialsToDatabase(username,password);
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        return credentialsMap;
             
    }
    private boolean usernameExists(String username) {

        try {
            // Establish a connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","password");

            // Create a statement
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM credentials WHERE username = ?");
            statement.setString(1, username);

            // Execute the query
            ResultSet resultSet = statement.executeQuery();

            // Check if the result set has any rows
            boolean exists = resultSet.next();

            // Close the connection
            connection.close();

            return exists;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    private void addCredentialsToDatabase(String username,String password) {
    	try {
            // Establish a connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","password");

            // Create a prepared statement
            PreparedStatement statement = connection.prepareStatement("INSERT INTO credentials (username, passeword) VALUES (?, ?)");
            statement.setString(1, username);
            statement.setString(2, password);

            // Execute the query
            statement.executeUpdate();
            System.out.println("        Credentials Addded successfully");
            System.out.println();
            System.out.println("       Enter '1' to redirect to login page");


            // Close the connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}