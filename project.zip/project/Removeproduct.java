//package project;
//import java.util.*;
//import java.io.FileReader;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.HashMap;
//
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//
//public class Removeproduct {
//	Scanner sc=new Scanner(System.in);
//	public void removeProduct() {
//	    JSONArray deleteProductsArray = readJsonFile("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/deleteproduct.json");
//
//	    // Connect to MySQL database
//	    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
//	        // Iterate over each product to be deleted
//	        for (Object productObj : deleteProductsArray) {
//	            JSONObject productJson = (JSONObject) productObj;
//
//	            // Parse JSON object to get product ID
//	            String productIdToDelete = (String) productJson.get("productid");
//
//	            // Retrieve product details for the given product ID
//	            String sqlSelect = "SELECT * FROM productdetails WHERE productid = ?";
//	            PreparedStatement selectStatement = conn.prepareStatement(sqlSelect);
//	            selectStatement.setString(1, productIdToDelete);
//	            ResultSet resultSet = selectStatement.executeQuery();
//
//	            if (resultSet.next()) {
//	                // Display product details
//	            	System.out.printf("%-5s %-10s %-20s %-8s %-12s %-12s %-8s %-6s %-6s %-6s%n",
//                            "ID", "Product ID", "Product Name", "Quantity", "Cost Price", "Selling Price", "Discount", "CGST", "SGST", "IGST");
//	            	
//	            	System.out.printf("%-5d %-10s %-20s %-8d %-12.2f %-12.2f %-8d %-6.1f %-6.1f %-6.1f%n",
//	            			resultSet.getInt("id"),resultSet.getString("productid"),resultSet.getString("productname"),resultSet.getInt("quantity"),resultSet.getDouble("costprice"),resultSet.getDouble("sellingprice"),resultSet.getInt("discount"),resultSet.getDouble("cgst"),resultSet.getDouble("sgst"),resultSet.getDouble("igst"));
//	            	System.out.println();
//
//	                
//	                // Prompt user to confirm deletion
//	                System.out.print("		  Press '1' to remove this product: ");
//	                int userInput = sc.nextInt();
//	                
//	                // If user confirms deletion, proceed to delete the product
//	                if (userInput == 1) {
//	                    // Prepare SQL statement to delete product based on product ID
//	                    String sqlDelete = "DELETE FROM productdetails WHERE productid = ?";
//	                    PreparedStatement deleteStatement = conn.prepareStatement(sqlDelete);
//	                    deleteStatement.setString(1, productIdToDelete);
//
//	                    // Execute SQL statement
//	                    int rowsDeleted = deleteStatement.executeUpdate();
//	                    if (rowsDeleted > 0) {
//	                        System.out.println("Product with ID " + productIdToDelete + " has been deleted successfully!");
//	                    } else {
//	                        System.out.println("Product with ID " + productIdToDelete + " does not exist!");
//	                    }
//	                } else {
//	                    System.out.println("Deletion canceled.");
//	                }
//	            } else {
//	                System.out.println("Product with ID " + productIdToDelete + " does not exist!");
//	            }
//	        }
//	    } catch (SQLException ex) {
//	        ex.printStackTrace();
//	    }
//	}
//	private static JSONArray readJsonFile(String filename) {
//        try {
//            JSONParser parser = new JSONParser();
//            FileReader reader = new FileReader(filename);
//            return (JSONArray) parser.parse(reader);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
//
//}

package project;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Removeproduct {
    Scanner sc = new Scanner(System.in);

    public void removeProduct() {
        JSONArray deleteProductsArray = readJsonFile("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/deleteproduct.json");

        // Connect to MySQL database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            // Iterate over each product to be deleted
            for (Object productObj : deleteProductsArray) {
                JSONObject productJson = (JSONObject) productObj;

                // Parse JSON object to get product ID
                String productIdToDelete = (String) productJson.get("productid");

                // Retrieve product details for the given product ID
                String sqlSelect = "SELECT * FROM productdetails WHERE productid = ?";
                PreparedStatement selectStatement = conn.prepareStatement(sqlSelect);
                selectStatement.setString(1, productIdToDelete);
                ResultSet resultSet = selectStatement.executeQuery();

                if (resultSet.next()) {
                    // Display product details
                    System.out.printf("%-5s %-10s %-20s %-20s %-8s %-12s %-12s %-8s %-6s %-6s %-6s%n",
                            "ID", "Product ID", "Product Name", "Goods Type", "Quantity", "Cost Price", "Selling Price", "Discount", "CGST", "SGST", "IGST");

                    System.out.printf("%-5d %-10s %-20s %-20s %-8d %-12.2f %-12.2f %-8d %-6.1f %-6.1f %-6.1f%n",
                            resultSet.getInt("id"), resultSet.getString("productid"), resultSet.getString("productname"), resultSet.getString("goodstype"),
                            resultSet.getInt("quantity"), resultSet.getDouble("costprice"), resultSet.getDouble("sellingprice"),
                            resultSet.getInt("discount"), resultSet.getDouble("cgst"), resultSet.getDouble("sgst"), resultSet.getDouble("igst"));
                    System.out.println();

                    // Prompt user to confirm deletion
                    System.out.print("Press '1' to remove this product: ");
                    int userInput = sc.nextInt();

                    // If user confirms deletion, proceed to delete the product
                    if (userInput == 1) {
                        // Prepare SQL statement to delete product based on product ID
                        String sqlDelete = "DELETE FROM productdetails WHERE productid = ?";
                        PreparedStatement deleteStatement = conn.prepareStatement(sqlDelete);
                        deleteStatement.setString(1, productIdToDelete);

                        // Execute SQL statement
                        int rowsDeleted = deleteStatement.executeUpdate();
                        if (rowsDeleted > 0) {
                            System.out.println("Product with ID " + productIdToDelete + " has been deleted successfully!");
                        } else {
                            System.out.println("Product with ID " + productIdToDelete + " does not exist!");
                        }
                    } else {
                        System.out.println("Deletion canceled.");
                    }
                } else {
                    System.out.println("Product with ID " + productIdToDelete + " does not exist!");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static JSONArray readJsonFile(String filename) {
        try {
            JSONParser parser = new JSONParser();
            FileReader reader = new FileReader(filename);
            return (JSONArray) parser.parse(reader);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
