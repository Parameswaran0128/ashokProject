package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Createbill {
	static int count;
	private static final Map<String, Integer> purchaseList = new HashMap<>();
	public static void enterProducts() {
		count=0;
	    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
	        Scanner scanner = new Scanner(System.in);
	        String productId;
	        int quantity;

	        while (true) {
	            System.out.print("	Enter the product ID (0 to finish): ");
	            productId = scanner.nextLine();
	            if (productId.equals("0")) {
	                break;
	            }

	            System.out.print("		Enter the quantity: ");
	            quantity = scanner.nextInt();

	            if (checkAvailability(connection, productId, quantity)) {
	                if (purchaseList.containsKey(productId)) {
	                    // If product already exists in the purchase list, update the quantity
	                    int existingQuantity = purchaseList.get(productId);
	                    purchaseList.put(productId, existingQuantity + quantity);
	                } else {
	                    // If product is not in the purchase list, add it with the given quantity
	                    purchaseList.put(productId, quantity);
	                }
	                System.out.println();
	                System.out.println("	Product added to the purchase list.");
	                System.out.println();
	                updateQuantity(connection, productId, quantity);
	            } else {
	                System.out.println("Product ID not available or required quantity is not available.");
	            }

	            scanner.nextLine(); // Consume newline left by nextInt
	        }

	        while (true) {
	        	System.out.println();
	            System.out.println("		Enter 1 to view the Cart:");
	            System.out.println();
	            System.out.println("	Enter 2 to discard and return to dashboard");
	            System.out.println();
	            System.out.println("	 Enter 3 to add more products to cart");
	            System.out.println();
	            System.out.println(" 	  Enter 4 to Exit once bill generated");
	            System.out.println();
	            System.out.print("		Enter your choice: ");
	           
	            int choice = scanner.nextInt();
	            switch (choice) {
	                case 1:
	                    viewCart(purchaseList);
	                    break;
	                case 2:
	                    re_addQuantity(purchaseList);
	                    return;
	                case 3:
	                    enterProducts(); // Recursively call enterProducts to add more products to cart
	                case 4:
	                	if(count!=0) {
	                		purchaseList.clear();
	                	return;
	                	}
	                	else {
	                	System.out.println();
	                	System.out.println("!!! You didn't generated Bill !!!");
	                	System.out.println();
	                	System.out.println("if u want to exit dicard the products then exit");
	                	System.out.println("Enter '2' to discard and exit");
	                	}
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}




	private static boolean checkAvailability(Connection connection, String productId, int quantity) {
        String query = "SELECT quantity FROM productdetails WHERE productid = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, productId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int availableQuantity = resultSet.getInt("quantity");
                return availableQuantity >= quantity;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    private static void updateQuantity(Connection connection, String productId, int purchasedQuantity) {
        String updateQuery = "UPDATE productdetails SET quantity = quantity - ? WHERE productid = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setInt(1, purchasedQuantity);
            preparedStatement.setString(2, productId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static void viewCart(Map<String, Integer> purchaseList) {
        if (purchaseList.isEmpty()) {
        	System.out.println();
            System.out.println("	'''''No products are in the Cart'''''");
            System.out.println();
            return;
        }
        Scanner sc=new Scanner(System.in);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            // Print header
            System.out.printf("%-10s %-20s %-10s %-15s %-10s %-10s %-10s %-10s %-10s %-15s%n",
                    "Product ID", "Product Name", "Quantity", "Selling Price", "Discount", "CGST", "SGST", "IGST", "Total Price (GST)", "After discount");

            // Iterate over each product in the purchase list
            for (Map.Entry<String, Integer> entry : purchaseList.entrySet()) {
                String productId = entry.getKey();
                int quantity = entry.getValue();

                // Retrieve product details for the given product ID
                String sqlSelect = "SELECT * FROM productdetails WHERE productid = ?";
                try (PreparedStatement selectStatement = conn.prepareStatement(sqlSelect)) {
                    selectStatement.setString(1, productId);
                    try (ResultSet resultSet = selectStatement.executeQuery()) {
                        if (resultSet.next()) {
                            String productName = resultSet.getString("productname");
                            double sellingPrice = resultSet.getDouble("sellingprice");
                            int discount = resultSet.getInt("discount");
                            double cgst = resultSet.getDouble("cgst");
                            double sgst = resultSet.getDouble("sgst");
                            double igst = resultSet.getDouble("igst");

                            // Calculate total price after discount
//                            double totalPriceAfterDiscount = calculateTotalPriceAfterDiscount(sellingPrice, discount);
//                            double totalPriceAfterDiscount = (sellingPrice*quantity)-((discount/100.0)*(sellingPrice*quantity));

                            // Calculate total GST
                            double totalGST = cgst + sgst + igst;

                            // Calculate total price after GST
//                            double totalPriceAfterGST = totalPriceAfterDiscount+((totalGST/100.0)*totalPriceAfterDiscount);
                            double totalPriceAfterGST=(sellingPrice*quantity)+((totalGST/100.0)*(sellingPrice*quantity));
                            double totalPriceAfterDiscount=totalPriceAfterGST-((discount/100.0)*totalPriceAfterGST);
                            

                            // Print product details in table format
                            System.out.printf("%-10s %-20s %-10s %-15s %-10s %-10.2f %-10s %-10s %-17s %-15.2f%n",
                                    productId, productName, quantity, sellingPrice, discount, cgst, sgst, igst, totalPriceAfterGST, totalPriceAfterDiscount);
                            System.out.println();
                            
                        } else {
                            System.out.println("Product with ID " + productId + " not found in database.");
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        while(true) {
        	System.out.println();
        	System.out.println("	Enter 1 for print Bill");
        	System.out.println();
        	System.out.println("	Enter 2 for exit");
        	System.out.println();
        	System.out.print("	  Enter your choice: ");
        	int get=sc.nextInt();
        	switch(get) {
        	case 1:
        		Printbill pb=new Printbill();
        		System.out.println();
        		pb.generatePDFBill(purchaseList);
        		count=1;
        		return;
        	case 2:
        		return;
        	}
        	
        }
    }

    private static double calculateTotalPriceAfterDiscount(double sellingPrice, int discount) {
        if (discount > 0) {
            // Calculate discounted price
            double discountAmount = (discount / 100.0) * sellingPrice;
            return sellingPrice - discountAmount;
        } else {
            // No discount
            return sellingPrice;
        }
    }
    private static void re_addQuantity(Map<String, Integer> purchaselist2) {
    	try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            for (Map.Entry<String, Integer> entry : purchaseList.entrySet()) {
                String productId = entry.getKey();
                int purchasedQuantity = entry.getValue();
                String updateQuery = "UPDATE productdetails SET quantity = quantity + ? WHERE productid = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                    preparedStatement.setInt(1, purchasedQuantity);
                    preparedStatement.setString(2, productId);
                    preparedStatement.executeUpdate();
                    System.out.println();
                    System.out.println("Quantity of Product ID: " + productId + " re-added to the stock.");
                    System.out.println();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            purchaseList.clear(); // Clear the purchase list after re-adding quantities
            System.out.println("	All quantities re-added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
	}
}
