package project;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Addproducts {
    public void addProducts() {
        JSONArray productsArray = readJsonFile("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/products.json");

        // Connect to MySQL database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            // Iterate over each product
            for (Object productObj : productsArray) {
                JSONObject productJson = (JSONObject) productObj;

                // Parse JSON object into a HashMap
                HashMap<String, Object> productDetails = parseJsonToMap(productJson);

                if (!productExists(conn, (String) productDetails.get("productid"))) {
                    // Prepare SQL statement
                    String sql = "INSERT INTO productdetails (productid, productname, goodstype, quantity, costprice, sellingprice, discount, cgst, sgst, igst) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement statement = conn.prepareStatement(sql);

                    // Set values from HashMap
                    statement.setString(1, (String) productDetails.get("productid"));
                    statement.setString(2, (String) productDetails.get("productname"));
                    statement.setString(3, (String) productDetails.get("goodstype"));
                    statement.setInt(4, (int) productDetails.get("quantity"));
                    statement.setDouble(5, (Double) productDetails.get("costprice"));
                    statement.setDouble(6, (Double) productDetails.get("sellingprice"));
                    statement.setInt(7, (int) productDetails.get("discount"));
                    statement.setDouble(8, (Double) productDetails.get("cgst"));
                    statement.setDouble(9, (Double) productDetails.get("sgst"));
                    statement.setDouble(10, (Double) productDetails.get("igst"));

                    // Execute SQL statement
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("      A new product was inserted successfully!");
                    }
                } else {
                    System.out.println("              Product already exists: " + productDetails.get("productname"));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static JSONArray readJsonFile(String filename) {
        try {
            JSONParser parser = new JSONParser();
            FileReader reader = new FileReader(filename);
            return (JSONArray) parser.parse(reader);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static HashMap<String, Object> parseJsonToMap(JSONObject jsonObject) {
        HashMap<String, Object> map = new HashMap<>();
        for (Object key : jsonObject.keySet()) {
            String keyStr = (String) key;
            Object value = jsonObject.get(keyStr);
            // Check the data type and handle accordingly
            if (value instanceof Long) {
                // Handle Long type appropriately, e.g., convert to Integer
                map.put(keyStr, ((Long) value).intValue()); // Convert Long to Integer
            } else {
                map.put(keyStr, value);
            }
        }
        return map;
    }

    private static boolean productExists(Connection conn, String productId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM productdetails WHERE productid = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, productId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }
        return false;
    }
}
