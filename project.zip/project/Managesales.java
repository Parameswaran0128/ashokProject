package project;
import java.util.*;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
public class Managesales {
	Scanner sc=new Scanner(System.in);
	String inputUsername=new String();
	public void askChoice() {
		
		while(true) {
			System.out.println();
			System.out.println("--------------Sales Management--------------");
			System.out.println();
			System.out.println("            Press '1' for Add Sales Person ");
			System.out.println();
			System.out.println("          Press '2' for Remove Sales Person ");
			System.out.println();
			System.out.println("            Press '3' for back to home ");
			System.out.println();
			System.out.print("                Enter the number: ");
			int user=sc.nextInt();
			System.out.println();
			System.out.println("-------------xxxxxxxxxxxxxxxxxxxxxxxxx---------------");
			System.out.println();
			
			switch(user) {
			case 1:
				Signup sp=new Signup();
				break;
			case 2:
				System.out.print("       Enter the username to delete: ");
	            inputUsername = sc.next();
	            System.out.println();
				removeSalesPerson();
				break;
			case 3:
				return;
			default:
				System.out.println("            Please enter the correct number");
				System.out.println();
			}	
		}
		
	}

	private void removeSalesPerson() {
		// TODO Auto-generated method stub
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","password")) {

            // Create the PreparedStatement
            try (PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM credentials WHERE username = ?")) {
                preparedStatement.setString(1, inputUsername);

                // Execute the delete query
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("   Username and corresponding password deleted successfully.");
                } else {
                    System.out.println("           Username not found in the table");
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
	}
}
