package project;
import java.util.*;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
public class Taxmanagement {
    private static Scanner scanner = new Scanner(System.in);

    public static void choice() {
        while (true) {
            System.out.println();
            System.out.println("Tax Management");
            System.out.println("Enter '1' for Add/Update tax");
            System.out.println("Enter '2' for get tax for a month");
            System.out.println();
            System.out.println("Enter '2' for Exit");
            System.out.println();
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    addTax();
                    break;
                case 2:
                    viewTax();
                    break;
                case 3:
                	return;
                default:
                    System.out.println("Invalid choice. Please enter 1 or 2.");
                    break;
            }
        }
    }

    private static void viewTax() {
    	try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            // Prompt user for the month and year
            System.out.println();
            System.out.print("Enter the month (1-12): ");
            int month = scanner.nextInt();
            System.out.print("Enter the year: ");
            int year = scanner.nextInt();
            System.out.println();

            // Construct the start and end dates for the given month and year
            String startDate = String.format("%04d-%02d-01 00:00:00", year, month);
            String endDate = String.format("%04d-%02d-31 23:59:59", year, month);

            // SQL query to calculate total tax for the specified month
            String query = "SELECT SUM(cgst) AS total_cgst, SUM(sgst) AS total_sgst, SUM(igst) AS total_igst " +
                           "FROM bill_history " +
                           "WHERE generation_datetime BETWEEN ? AND ?";
            
            // Prepare and execute the query
            try (PreparedStatement statement = conn.prepareStatement(query)) {
                statement.setString(1, startDate);
                statement.setString(2, endDate);
                ResultSet resultSet = statement.executeQuery();

                // Retrieve and print the total tax amounts
                if (resultSet.next()) {
                    double totalCgst = resultSet.getDouble("total_cgst");
                    double totalSgst = resultSet.getDouble("total_sgst");
                    double totalIgst = resultSet.getDouble("total_igst");
                    
                    System.out.println("Total CGST for the month: $" + totalCgst);
                    System.out.println("Total SGST for the month: $" + totalSgst);
                    System.out.println("Total IGST for the month: $" + totalIgst);
                } else {
                    System.out.println("No tax data found for the specified month.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addTax() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            // Prompt user for goodstype
            System.out.println();
            System.out.print("Enter goodstype: ");
            String goodstype = scanner.next();

            // Check if goodstype exists in the productdetails table
            String checkQuery = "SELECT * FROM productdetails WHERE goodstype = ?";
            try (PreparedStatement checkStatement = conn.prepareStatement(checkQuery)) {
                checkStatement.setString(1, goodstype);
                try (ResultSet resultSet = checkStatement.executeQuery()) {
                    if (!resultSet.next()) {
                        System.out.println();
                        System.out.println("Goodstype not found.");
                        return;
                    }
                }
            }

            // Prompt user for new tax values
            System.out.print("Enter new CGST: ");
            double newCgst = scanner.nextDouble();
            System.out.println();
            System.out.print("Enter new SGST: ");
            double newSgst = scanner.nextDouble();
            System.out.println();
            System.out.print("Enter new IGST: ");
            double newIgst = scanner.nextDouble();
            System.out.println();

            // Update or insert tax values into productdetails table
            String updateQuery = "UPDATE productdetails SET cgst = ?, sgst = ?, igst = ? WHERE goodstype = ?";
            try (PreparedStatement updateStatement = conn.prepareStatement(updateQuery)) {
                updateStatement.setDouble(1, newCgst);
                updateStatement.setDouble(2, newSgst);
                updateStatement.setDouble(3, newIgst);
                updateStatement.setString(4, goodstype);

                int rowsAffected = updateStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println();
                    System.out.println("Tax values updated successfully.");
                } else {
                    System.out.println();
                    System.out.println("Failed to update tax values.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}