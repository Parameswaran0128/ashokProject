package project;

import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {
	public HashMap<String, String> credentials;
	public String salorman=new String();
    public Login() {
        credentials = readCredentialsFromJson();
        //System.out.print(credentials);
    }

    private HashMap<String, String> readCredentialsFromJson() {
        HashMap<String, String> credentialsMap = new HashMap<>();
        JSONParser parser = new JSONParser();
        try {
        	Object obj = parser.parse(new FileReader("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/login.json"));
            JSONObject jsonObject = (JSONObject) obj;
            for (Object key : jsonObject.keySet()) {
                String username = (String) key;
                String password = (String) jsonObject.get(key);
                credentialsMap.put(username, password);

            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        return credentialsMap;
    }

    public void validateLogin() {
	    try {
	        // Establish a connection
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","password");
	
	        // Create a statement
	        Statement statement = connection.createStatement();
	
	        // Query the database
	        String query = "SELECT * FROM credentials WHERE username='" + credentials.get("username") +
	                "' AND passeword='" + credentials.get("password") + "'";
	        ResultSet resultSet = statement.executeQuery(query);

	        if (resultSet.next()) {
	            System.out.println("           Credentials verified Successfully!!!");
	            salorman=credentials.get("username");
	            if(salorman.contains("sal")) {
	            	//System.out.println("sales page");
	            	Sales ss=new Sales();
	            }
	            else {
	            	Manager mr=new Manager();
	            	Main m=new Main();
	            	//System.out.print("manager page");
	            }
	        }
	        else {
	        	System.out.println("               No Users Found!!!");
	        	System.out.println();
	        	System.out.println("          To create an account enter '2'");
	        }
	
	        // Close the connection
	        connection.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
    }


}