package project;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Updateproduct {
    public void updateProduct() {
        JSONArray updateProductsArray = readJsonFile("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/updateproduct.json");

        // Connect to MySQL database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
            // Iterate over each product to be updated
            for (Object productObj : updateProductsArray) {
                JSONObject productJson = (JSONObject) productObj;

                // Parse JSON object to get product ID and details
                String productIdToUpdate = (String) productJson.get("productid");
                String productName = (String) productJson.get("productname");
                String goodsType = (String) productJson.get("goodstype");
                int quantity = Integer.parseInt(productJson.get("quantity").toString());
                double costPrice = Double.parseDouble(productJson.get("costprice").toString());
                double sellingPrice = Double.parseDouble(productJson.get("sellingprice").toString());
                int discount = Integer.parseInt(productJson.get("discount").toString());
                double cgst = Double.parseDouble(productJson.get("cgst").toString());
                double sgst = Double.parseDouble(productJson.get("sgst").toString());
                double igst = Double.parseDouble(productJson.get("igst").toString());
             // Check if the product exists in the table
	            if (productExists(conn, productIdToUpdate)) {
	                // Retrieve current details of the product
	                String sqlSelect = "SELECT * FROM productdetails WHERE productid = ?";
	                PreparedStatement selectStatement = conn.prepareStatement(sqlSelect);
	                selectStatement.setString(1, productIdToUpdate);
	                ResultSet resultSet = selectStatement.executeQuery();

	                if (resultSet.next()) {
	                    // Check if no changes are made in the new details
	                    if (productName.equals(resultSet.getString("productname")) &&
	                            quantity == resultSet.getInt("quantity") &&
	                            costPrice == resultSet.getDouble("costprice") &&
	                            sellingPrice == resultSet.getDouble("sellingprice") &&
	                            discount == resultSet.getInt("discount") &&
	                            cgst == resultSet.getDouble("cgst") &&
	                            sgst == resultSet.getDouble("sgst") &&
	                            igst == resultSet.getDouble("igst")) {
	                        System.out.println("All the details are already existed for this product.");
	                    } else {
	                        // Update the product details
	                        String sqlUpdate = "UPDATE productdetails SET productname = ?, quantity = ?, costprice = ?, sellingprice = ?, discount = ?, cgst = ?, sgst = ?, igst = ? WHERE productid = ?";
	                        PreparedStatement updateStatement = conn.prepareStatement(sqlUpdate);
	                        updateStatement.setString(1, productName);
	                        updateStatement.setInt(2, quantity);
	                        updateStatement.setDouble(3, costPrice);
	                        updateStatement.setDouble(4, sellingPrice);
	                        updateStatement.setInt(5, discount);
	                        updateStatement.setDouble(6, cgst);
	                        updateStatement.setDouble(7, sgst);
	                        updateStatement.setDouble(8, igst);
	                        updateStatement.setString(9, productIdToUpdate);

	                        // Execute SQL statement
	                        int rowsUpdated = updateStatement.executeUpdate();
	                        if (rowsUpdated > 0) {
	                            System.out.println("Changes made successfully for product with ID: " + productIdToUpdate);
	                        }
	                    }
	                }
	            } else {
	                System.out.println("Product with ID " + productIdToUpdate + " does not exist!");
	            }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static JSONArray readJsonFile(String filename) {
        try {
            JSONParser parser = new JSONParser();
            FileReader reader = new FileReader(filename);
            return (JSONArray) parser.parse(reader);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean productExists(Connection conn, String productId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM productdetails WHERE productid = ?";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, productId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        }
        return false;
    }
}
