package project;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;

public class Saleshistory {

	public void addHistory(Map<String, Integer> purchase, String randomBillNumber, String string) {
		String billingperson = getBillingperson();
		
	    LocalDateTime generationDatetime = LocalDateTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	    String formattedDateTime = generationDatetime.format(formatter);

	    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
	        for (Map.Entry<String, Integer> entry : purchase.entrySet()) {
	            String productId = entry.getKey();
	            int quantity = entry.getValue();
	            String productName = ""; // Placeholder for product name
	            double sellingPrice = 0.0; // Placeholder for selling price
	            int discount = 0; // Placeholder for discount
	            double cgst=0.0;
	            double sgst=0.0;
	            double igst=0.0;
	            double totalAfterDiscount=0.0;
	            double totalAfterGST=0.0;
	            double totalGSTAmount=0.0;

	            // Retrieve product details from productdetails table
	            String selectQuery = "SELECT productname, sellingprice, discount,cgst,sgst,igst FROM productdetails WHERE productid = ?";
	            try (PreparedStatement preparedStatement = conn.prepareStatement(selectQuery)) {
	                preparedStatement.setString(1, productId);
	                try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                    if (resultSet.next()) {
	                        productName = resultSet.getString("productname");
	                        sellingPrice = resultSet.getDouble("sellingprice");
	                        discount = resultSet.getInt("discount");
	                        cgst=resultSet.getDouble("cgst");
	                        sgst=resultSet.getDouble("sgst");
	                        igst=resultSet.getDouble("igst");
	                        
	                        double totalPrice=sellingPrice*quantity;
	                        double totalgst=cgst+sgst+igst;
	                        totalGSTAmount=(((totalgst)/100.0)*totalPrice);
	                        
	                        totalAfterGST=totalPrice+totalGSTAmount;
	                        totalAfterDiscount=totalAfterGST-((discount/100.0)*totalAfterGST);
	                    }
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }

	            //double totalPriceAfterDiscount = calculateTotalPriceAfterDiscount(sellingPrice, discount);

	            // Insertion query
	            String insertQuery = "INSERT INTO bill_history (bill_no, mode_of_pay, generation_datetime, billingperson, product_id, product_name, quantity, selling_price, discount, total_price_after_discount, cgst, sgst, igst, total_price_after_gst) " +
	                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	            try (PreparedStatement preparedStatement = conn.prepareStatement(insertQuery)) {
	                preparedStatement.setString(1, randomBillNumber);
	                preparedStatement.setString(2, string);
	                preparedStatement.setString(3, formattedDateTime);
	                preparedStatement.setString(4, billingperson);
	                preparedStatement.setString(5, productId);
	                preparedStatement.setString(6, productName);
	                preparedStatement.setInt(7, quantity);
	                preparedStatement.setDouble(8, sellingPrice);
	                preparedStatement.setInt(9, discount);
	                preparedStatement.setDouble(10, totalAfterDiscount);
	                preparedStatement.setDouble(11, cgst); 
	                preparedStatement.setDouble(12, sgst); 
	                preparedStatement.setDouble(13, igst); 
	                preparedStatement.setDouble(14, totalAfterGST);
	                preparedStatement.executeUpdate();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		
	}
	public static String getBillingperson() {
		String salesman = "";
	    // Parse JSON file and extract username
	    try {
	        // JSON parser
	        JSONParser parser = new JSONParser();
	        
	        // Read JSON file
	        Object obj = parser.parse(new FileReader("C:/Users/ashok_a/eclipse-workspace/SBM/src/project/login.json"));
	        
	        // Convert object to JSONObject
	        JSONObject jsonObject = (JSONObject) obj;
	        
	        // Retrieve username from JSON object
	        salesman = (String) jsonObject.get("username");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return salesman;
	}
	public static void viewHistory() {
		 try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "password")) {
	            // Query to fetch distinct bill numbers
	            String selectDistinctBillNosQuery = "SELECT DISTINCT bill_no FROM bill_history";
	            
	            try (PreparedStatement preparedStatement = conn.prepareStatement(selectDistinctBillNosQuery);
	                 ResultSet resultSet = preparedStatement.executeQuery()) {
	                
	                while (resultSet.next()) {
	                    String billNo = resultSet.getString("bill_no");
	                    System.out.println("Bill No: " + billNo);
	                    System.out.println("---------------------------------------------------------");
	                    printBillDetailsForBillNo(conn, billNo);
	                    System.out.println("---------------------------------------------------------\n");
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	}
	private static void printBillDetailsForBillNo(Connection conn, String billNo) throws SQLException {
        // Query to fetch bill details for a specific bill number
        String selectBillDetailsQuery = "SELECT * FROM bill_history WHERE bill_no = ?";
        
        try (PreparedStatement preparedStatement = conn.prepareStatement(selectBillDetailsQuery)) {
            preparedStatement.setString(1, billNo);
            
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                DecimalFormat df = new DecimalFormat("#.##"); // Format for decimal numbers
                
                while (resultSet.next()) {
                    String productId = resultSet.getString("product_id");
                    String productName = resultSet.getString("product_name");
                    String modeofPay = resultSet.getString("mode_of_pay");
                    String generationDateTime = resultSet.getString("generation_datetime");
                    String generatedPerson = resultSet.getString("billingperson");
                    int quantity = resultSet.getInt("quantity");
                    double sellingPrice = resultSet.getDouble("selling_price");
                    int discount = resultSet.getInt("discount");
                    double cgst = resultSet.getDouble("cgst");
                    double sgst = resultSet.getDouble("sgst");
                    double igst = resultSet.getDouble("igst");
                    double totalPriceAfterDiscount = resultSet.getDouble("total_price_after_discount");
                    double totalPriceAfterGST = resultSet.getDouble("total_price_after_gst");
                    
                    System.out.println("Product ID: " + productId);
                    System.out.println("Product Name: " + productName);
                    System.out.println("Mode of pay: " + modeofPay);
                    System.out.println("Bill Generated on: " + generationDateTime);
                    System.out.println("Bill Generated by: " + generatedPerson);
                    System.out.println("Quantity: " + quantity);
                    System.out.println("Selling Price: $" + df.format(sellingPrice));
                    System.out.println("Discount: " + discount + "%");
                    System.out.println("CGST: $" + df.format(cgst));
                    System.out.println("SGST: $" + df.format(sgst));
                    System.out.println("IGST: $" + df.format(igst));
                    System.out.println("Total Price After Discount: $" + df.format(totalPriceAfterDiscount));
                    System.out.println("Total Price After GST: $" + df.format(totalPriceAfterGST));
                    System.out.println();
                }
            }
        }
    }
}
	
	
